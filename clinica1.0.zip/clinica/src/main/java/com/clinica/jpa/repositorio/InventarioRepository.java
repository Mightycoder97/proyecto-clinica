package com.clinica.jpa.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.clinica.jpa.modelo.Inventario;

import java.util.List;

@Repository
public interface InventarioRepository extends JpaRepository<Inventario, Long> {
    List<Inventario> findByNombre(String nombre);
    List<Inventario> findByCantidad(Integer cantidad);
    List<Inventario> findByPrecio(Double precio);
}

