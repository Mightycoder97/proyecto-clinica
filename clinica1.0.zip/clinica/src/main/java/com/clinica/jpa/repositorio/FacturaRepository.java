package com.clinica.jpa.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.clinica.jpa.modelo.Factura;
import com.clinica.jpa.modelo.Paciente;

import java.util.List;
import java.util.Date;

@Repository
public interface FacturaRepository extends JpaRepository<Factura, Long> {
    List<Factura> findByPaciente(Paciente paciente);
    List<Factura> findByMetodoPago(Factura.MetodoPago metodoPago);
    List<Factura> findByFecha(Date fecha);
    List<Factura> findByTotal(Double total);
}

