package com.clinica.jpa.servicio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clinica.jpa.modelo.Factura;
import com.clinica.jpa.modelo.Paciente;
import com.clinica.jpa.repositorio.FacturaRepository;

import java.util.List;
import java.util.Optional;

@Service
public class FacturaService {

    @Autowired
    private FacturaRepository facturaRepository;

    public Factura crearFactura(Factura factura) {
        return facturaRepository.save(factura);
    }

    public List<Factura> obtenerTodasFacturas() {
        return facturaRepository.findAll();
    }

    public Optional<Factura> obtenerFacturaPorId(Long id) {
        return facturaRepository.findById(id);
    }

    public List<Factura> buscarFacturasPorPaciente(Paciente paciente) {
        return facturaRepository.findByPaciente(paciente);
    }

    public List<Factura> buscarFacturasPorMetodoPago(Factura.MetodoPago metodoPago) {
        return facturaRepository.findByMetodoPago(metodoPago);
    }

    public void eliminarFactura(Long id) {
        facturaRepository.deleteById(id);
    }
}
