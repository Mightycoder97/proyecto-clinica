package com.clinica.jpa.modelo;

import jakarta.persistence.*;

@Entity
public class Turno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idTurno;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_medico")
    private Medico medico;

    @Temporal(TemporalType.DATE)
    private java.util.Date fecha;

    @Temporal(TemporalType.TIME)
    private java.util.Date horaInicio;

    @Temporal(TemporalType.TIME)
    private java.util.Date horaFin;

    public Long getIdTurno() {
        return idTurno;
    }

    public void setIdTurno(Long idTurno) {
        this.idTurno = idTurno;
    }

    public Medico getMedico() {
        return medico;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    public java.util.Date getFecha() {
        return fecha;
    }

    public void setFecha(java.util.Date fecha) {
        this.fecha = fecha;
    }

    public java.util.Date getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(java.util.Date horaInicio) {
        this.horaInicio = horaInicio;
    }

    public java.util.Date getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(java.util.Date horaFin) {
        this.horaFin = horaFin;
    }
}
