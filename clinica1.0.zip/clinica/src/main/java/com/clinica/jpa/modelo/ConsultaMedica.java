package com.clinica.jpa.modelo;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;

@Entity
public class ConsultaMedica {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idConsulta;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_paciente")
    private Paciente paciente;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_medico")
    private Medico medico;

    @Temporal(TemporalType.DATE)
    private java.util.Date fecha;

    private String diagnostico;
    private String tratamiento;
    private String notas;

    @OneToMany(mappedBy = "consulta", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Receta> recetas;

	public Long getIdConsulta() {
		return idConsulta;
	}

	public void setIdConsulta(Long idConsulta) {
		this.idConsulta = idConsulta;
	}
	@JsonIgnore
	public Paciente getPaciente() {
		return paciente;
	}
	@JsonIgnore
	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}
	@JsonIgnore
	public Medico getMedico() {
		return medico;
	}
	@JsonIgnore
	public void setMedico(Medico medico) {
		this.medico = medico;
	}
	@JsonIgnore
	public java.util.Date getFecha() {
		return fecha;
	}
	@JsonIgnore
	public void setFecha(java.util.Date fecha) {
		this.fecha = fecha;
	}
	@JsonIgnore
	public String getDiagnostico() {
		return diagnostico;
	}
	@JsonIgnore
	public void setDiagnostico(String diagnostico) {
		this.diagnostico = diagnostico;
	}
	@JsonIgnore
	public String getTratamiento() {
		return tratamiento;
	}
	@JsonIgnore
	public void setTratamiento(String tratamiento) {
		this.tratamiento = tratamiento;
	}
	@JsonIgnore
	public String getNotas() {
		return notas;
	}
	@JsonIgnore
	public void setNotas(String notas) {
		this.notas = notas;
	}
	@JsonIgnore
	public List<Receta> getRecetas() {
		return recetas;
	}
	@JsonIgnore
	public void setRecetas(List<Receta> recetas) {
		this.recetas = recetas;
	}
    
}
