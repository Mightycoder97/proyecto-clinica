package com.clinica.jpa.controlador;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.clinica.jpa.modelo.Factura;
import com.clinica.jpa.modelo.Paciente;
import com.clinica.jpa.servicio.FacturaService;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/facturas")
public class FacturaController {

    @Autowired
    private FacturaService facturaService;

    @PostMapping
    public Factura crearFactura(@RequestBody Factura factura) {
        return facturaService.crearFactura(factura);
    }

    @GetMapping
    public List<Factura> obtenerTodasFacturas() {
        return facturaService.obtenerTodasFacturas();
    }

    @GetMapping("/{id}")
    public Optional<Factura> obtenerFacturaPorId(@PathVariable Long id) {
        return facturaService.obtenerFacturaPorId(id);
    }

    @GetMapping("/buscarPorPaciente")
    public List<Factura> buscarFacturasPorPaciente(@RequestParam Paciente paciente) {
        return facturaService.buscarFacturasPorPaciente(paciente);
    }

    @GetMapping("/buscarPorMetodoPago")
    public List<Factura> buscarFacturasPorMetodoPago(@RequestParam Factura.MetodoPago metodoPago) {
        return facturaService.buscarFacturasPorMetodoPago(metodoPago);
    }

    @DeleteMapping("/{id}")
    public void eliminarFactura(@PathVariable Long id) {
        facturaService.eliminarFactura(id);
    }
}
