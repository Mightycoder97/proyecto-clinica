package com.clinica.jpa.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.clinica.jpa.modelo.Especialidad;
import com.clinica.jpa.servicio.EspecialidadService;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/especialidades")
public class EspecialidadController {

    @Autowired
    private EspecialidadService especialidadService;

    @PostMapping
    public Especialidad crearEspecialidad(@RequestBody Especialidad especialidad) {
        return especialidadService.crearEspecialidad(especialidad);
    }

    @GetMapping
    public List<Especialidad> obtenerTodasEspecialidades() {
        return especialidadService.obtenerTodasEspecialidades();
    }

    @GetMapping("/{id}")
    public Optional<Especialidad> obtenerEspecialidadPorId(@PathVariable Long id) {
        return especialidadService.obtenerEspecialidadPorId(id);
    }

    @GetMapping("/buscarPorNombre")
    public List<Especialidad> buscarEspecialidadPorNombre(@RequestParam String nombre) {
        return especialidadService.buscarEspecialidadPorNombre(nombre);
    }

    @DeleteMapping("/{id}")
    public void eliminarEspecialidad(@PathVariable Long id) {
        especialidadService.eliminarEspecialidad(id);
    }
}

