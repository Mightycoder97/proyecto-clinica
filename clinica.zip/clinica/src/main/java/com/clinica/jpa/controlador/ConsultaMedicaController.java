package com.clinica.jpa.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.clinica.jpa.modelo.ConsultaMedica;
import com.clinica.jpa.modelo.Medico;
import com.clinica.jpa.modelo.Paciente;
import com.clinica.jpa.servicio.ConsultaMedicaService;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/consultas")
public class ConsultaMedicaController {

    @Autowired
    private ConsultaMedicaService consultaMedicaService;

    @PostMapping
    public ConsultaMedica crearConsultaMedica(@RequestBody ConsultaMedica consultaMedica) {
        return consultaMedicaService.crearConsultaMedica(consultaMedica);
    }

    @GetMapping
    public List<ConsultaMedica> obtenerTodasConsultas() {
        return consultaMedicaService.obtenerTodasConsultas();
    }

    @GetMapping("/{id}")
    public Optional<ConsultaMedica> obtenerConsultaPorId(@PathVariable Long id) {
        return consultaMedicaService.obtenerConsultaPorId(id);
    }

    @GetMapping("/buscarPorPaciente")
    public List<ConsultaMedica> buscarConsultasPorPaciente(@RequestParam Paciente paciente) {
        return consultaMedicaService.buscarConsultasPorPaciente(paciente);
    }

    @GetMapping("/buscarPorMedico")
    public List<ConsultaMedica> buscarConsultasPorMedico(@RequestParam Medico medico) {
        return consultaMedicaService.buscarConsultasPorMedico(medico);
    }

    @DeleteMapping("/{id}")
    public void eliminarConsulta(@PathVariable Long id) {
        consultaMedicaService.eliminarConsulta(id);
    }
}

