package com.clinica.jpa.servicio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clinica.jpa.modelo.Medico;
import com.clinica.jpa.repositorio.MedicoRepository;

import java.util.List;
import java.util.Optional;

@Service
public class MedicoService {

    @Autowired
    private MedicoRepository medicoRepository;

    public Medico crearMedico(Medico medico) {
        return medicoRepository.save(medico);
    }

    public List<Medico> obtenerTodosMedicos() {
        return medicoRepository.findAll();
    }

    public Optional<Medico> obtenerMedicoPorId(Long id) {
        return medicoRepository.findById(id);
    }

    public List<Medico> buscarMedicoPorNombre(String nombre) {
        return medicoRepository.findByNombre(nombre);
    }

    public List<Medico> buscarMedicoPorEspecialidad(String especialidad) {
        return medicoRepository.findByEspecialidad(especialidad);
    }

    public void eliminarMedico(Long id) {
        medicoRepository.deleteById(id);
    }
}
